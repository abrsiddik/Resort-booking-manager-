# Resort Booking Manager

## Double-booking prevention
The app blocks saving a booking if the same room already has an active booking with overlapping dates. The check applies when adding or editing a booking and includes both **Booked** and **Tentative** bookings. When editing, the booking being edited is excluded from the conflict check.

Check-in is inclusive and check-out is exclusive. For example, a stay from 20 October to 22 October occupies the nights of 20 and 21 October; another stay may start on 22 October.

## Run
Open `index.html` in a modern browser. On iPhone, deploy the folder to a static host and open the website URL in Safari if a local file preview does not run JavaScript.

## Storage limitation
Bookings are saved in browser local storage. This static version does not sync across devices or browsers. Export CSV and use **Backup data** regularly. To prevent conflicts between different devices/users, a shared database with server-side validation is required.
