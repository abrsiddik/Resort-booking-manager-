Resort Booking Manager — Booking Management Update

Open index.html in a modern browser. This remains a standalone app and saves data in the current browser's localStorage.

Features:
- Strict same-room overlap prevention, including reservations containing multiple rooms. Check-in is inclusive and check-out is exclusive.
- Edit booking details; change dates to reschedule or extend a stay.
- Cancel bookings without deleting the record; cancelled reservations release their room(s).
- Status options: Booked, Tentative, Checked-in, Checked-out, Cancelled.
- Search by guest name, phone, or booking ID; filter by room, active date, and status.
- Automatic night count, room-rate x nights x room count calculation, discount, total, and due.
- Multi-room reservation support.
- Upcoming check-ins, upcoming departures, and overdue check-out lists. Mark a stay Checked-out to remove it from overdue check-outs.
- CSV export includes room list, rate, and discount; JSON backup/restore remains available.

Data note: the app stores data on this browser/device only. It does not synchronize across staff devices. Download a JSON backup before replacing your old file, and import that backup into the updated version if needed.
